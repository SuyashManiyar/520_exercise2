# Coverage Report: HumanEval/114

**Code File:** `/Users/suyashmaniyar/Desktop/UMass/Courses/SoftwareEngineering/Assignment_02/HumanEval_Analysis_Final/codes_enhanced/gemma_Self_Planning/HumanEval_114.py`

**Test Cases:** 12

## Test Results

- **Passed:** 12
- **Failed:** 0
- **Total:** 12

## Coverage Metrics

- **Line Coverage:** 85.7%
- **Branch Coverage:** 75.0%

## Uncovered Lines

[15]

## Uncovered Branches

- Line 14: branches [15]

## Files Generated

- `coverage_report.txt` - Terminal output
- `coverage.json` - JSON coverage data
- `htmlcov/index.html` - Interactive HTML report
- `summary.md` - This file
